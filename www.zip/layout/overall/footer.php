				</div>
				<!-- MAIN FEED END -->

				<?php include 'layout/aside.php'; ?>
			</div>

			<footer class="well preventCollapse">
				<div class="pull-left">
					<p>&copy; <?php echo $config['site_title'];?>. <?php echo ' Page generated in '. elapsedTime() .' seconds. Q: '.$aacQueries; ?>. Designed By <a href="https://otland.net/members/snavy.155163/" target="_blank">Snavy</a>. Engine: <a href="credits.php">Znote AAC</a>.</p>
				</div>
				<div class="pull-right">
					<p><?php echo 'Server date and clock is: '. getClock(false, true); ?></p>
				</div>
				<!--
					Designed By <a href="https://otland.net/members/snavy.155163/" target="_blank">Snavy</a>
				-->


			</footer>
		</div><!-- Main container END -->
	</body>
</html>
<!--
	Layout author: Blackwolf (Snavy on otland)
	Otland: https://otland.net/members/snavy.155163/
	Facebook: http://www.facebook.com/idont.reallywolf.1
	Twitter: @idontreallywolf
	Converted to Znote AAC by: Znote
-->
